import random
import sys
import pygame 

class Eletron(pygame.sprite.Sprite):
    def __init__(self, pos, *groups):
        super().__init__(*groups)

        self.image = pygame.Surface((4, 4))
        self.rect = self.image.get_rect(topleft=pos)
        self.color = "white"
        self.image.fill(self.color)

        self.dir_x = random.randint(-1, 1)
        self.dir_y = random.randint(-1, 1)

    def update(self):
        self.rect.x += self.dir_x
        self.rect.y += self.dir_y

pygame.init()
tela = pygame.display.set_mode((1280, 720))

eletrons = pygame.sprite.Group()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                Eletron(event.pos, eletrons)

    tela.fill((0, 0, 0))
    eletrons.draw(tela)
    eletrons.update()
    pygame.display.flip()

